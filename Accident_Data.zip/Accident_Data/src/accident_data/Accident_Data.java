//ST10315122

//Author - Unknown
//Date - n.d
//https://www.w3schools.com/java/
//W3Schools (1998). W3Schools Online Web Tutorials. [online] W3schools.com. Available at: https://www.w3schools.com/.
//Accessed on [30 September 2024]


package accident_data;

import java.util.Scanner;  //Scanner input

public class Accident_Data {


            
    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);  //Scanner made here
        //Variables declared here
        int CapeTown = 0;
        int Johannesburg = 0;
        int PortElizabeth = 0;
        int Highest = 0;
        String CityHighest;
        
        //Arrays declared here
        int[][] Accidents = new int[3][2];
        String [] City = {"CAPE TOWN", "JOHANNESBURG", "PORT ELIZABETH"};
        String [] Type = {"CAR", "MOTOR BIKE"};        
        
        //Display messages to users and accepts inputs
        System.out.println("Enter the number of car accidents for Cape Town: ");
        Accidents[0][0] = scanner.nextInt();
                
        System.out.println("Enter the number of motor bike accidents for Cape Town: ");
         Accidents[0][1] = scanner.nextInt();
        
        System.out.println("Enter the number of car accidents for Johannesburg: ");
        Accidents[1][0] = scanner.nextInt();
        
         System.out.println("Enter the number of motor bike accidents for Johannesburg: ");
         Accidents[1][1] = scanner.nextInt();
         
          System.out.println("Enter the number of car accidents for Port Elizabeth: ");
          Accidents[2][0] = scanner.nextInt();
          
            System.out.println("Enter the number of motor bike accidents for Port Elizabeth: ");
        Accidents[2][1] = scanner.nextInt();
        
        //Dissplays messages to users
        System.out.println("----------------------------");
        System.out.println("ROAD ACCIDENT REPORT");
         System.out.println("----------------------------");
        
         System.out.println("\n"+"        "+Type[0]+"   "+Type[1]);
         for (int i=0; i<Accidents.length; i++){  //Loops through the arrays to display the arrays to the user
             
              System.out.println(City[i]+"   "+Accidents[i][0] +"   "+Accidents[i][1]);
             
             }
         
         //Calculates city total accidents
         CapeTown =      Accidents[0][0] + Accidents[0][1];
         Johannesburg =  Accidents[1][0] + Accidents[1][1];
         PortElizabeth = Accidents[2][0] + Accidents[2][1];
         
         //Display messages
          System.out.println("----------------------------");
          System.out.println("ROAD ACCIDENT TOTALS FOR EACH CITY");
          System.out.println("----------------------------");
          
          //Display messages with city totals accidenrs
          System.out.println("CAPE TOWN: "+CapeTown);
          System.out.println("JOHANNESBURG: "+Johannesburg);
          System.out.println("PORT ELIZABETH: "+PortElizabeth);
          
          //Calculating the city with the highest accidents
          if (CapeTown>Johannesburg){
              Highest = CapeTown;
              CityHighest = "Cape Town";
          }else if(Johannesburg > PortElizabeth){
              Highest = Johannesburg;
              CityHighest = "Johannesburg";
          } else{
              Highest = PortElizabeth;
              CityHighest = "Port Elizabeth";
          }
          
          //Display messages to the user
          System.out.println("\nCITY WITH THE MOST VEHICLE ACCIDENTS: "+CityHighest);
           System.out.println("----------------------------");
         
         }
    }
    

