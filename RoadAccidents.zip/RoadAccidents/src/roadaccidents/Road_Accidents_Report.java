//ST10315122

//Author - Unknown
//Date - n.d
//https://www.w3schools.com/java/
//W3Schools (1998). W3Schools Online Web Tutorials. [online] W3schools.com. Available at: https://www.w3schools.com/.
//Accessed on [30 September 2024]


package roadaccidents;

import java.util.Scanner;  //Scanner input
public class Road_Accidents_Report {

    
    
    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);  //Scanner object created here
        
        //Displays messages and recieves input from user
       System.out.println("Enter the accident vehicle type: ");
       String VehicleType = scanner.next();
       
       System.out.println("Enter the city for the vehicle accidents: ");
     String City = scanner.next();
     
     System.out.println("Enter the total Car accidents for"+" "+City+":");
    int TotalAccidents = scanner.nextInt();
    
    RoadAccidentReport Road = new RoadAccidentReport(VehicleType, City, TotalAccidents) {}; //Instantiates ProcessWorkout
    
    //Displays data to the user
    System.out.println("CITY ACCIDENT REPORT");
    System.out.println("**********************");
    Road.getVehicleType();
    Road.getCity();
    Road.getTotalAccidents();
    System.out.println("**********************");
    }
    
}
