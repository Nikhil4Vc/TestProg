
package roadaccidents;


public class RoadAccidentReport extends RoadAccidents {
//Constrcutor
    public RoadAccidentReport(String VehicleType, String City, int TotalAccidents) {
        super(VehicleType, City, TotalAccidents);
    }

    //Methods
    @Override
    public String getAccidentVehicleType() {
        System.out.println("Vehicle Type: "+getVehicleType());
        return null;
    }

    @Override
    public int getAccidentTotal() {
        System.out.println("ACCIDENT TOTAL: "+getTotalAccidents());
        return 0;
        
    }
    
}
