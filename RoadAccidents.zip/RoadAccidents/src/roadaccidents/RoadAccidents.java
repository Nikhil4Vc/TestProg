
package roadaccidents;


abstract class RoadAccidents implements IRoadAccidents {
    //Variables created here
    private String VehicleType;
    private String City;
    private int TotalAccidents;

    //Constrcuctor
    public RoadAccidents(String VehicleType, String City, int TotalAccidents) {
        this.VehicleType = VehicleType;
        this.City = City;
        this.TotalAccidents = TotalAccidents;
    }

    //Getter methods
    public String getVehicleType() {
        return VehicleType;
    }

    public String getCity() {
        return City;
    }

    public int getTotalAccidents() {
        return TotalAccidents;
    }
    
    
}
