
package roadaccidents;


public interface IRoadAccidents {  //Interface class with methods
    String getAccidentVehicleType();
    String getCity();
    int getAccidentTotal();
}
